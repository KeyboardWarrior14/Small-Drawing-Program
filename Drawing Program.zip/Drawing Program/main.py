# Drawing Program
# Add feature that text turns white when colored on top of
# Add feature where you can load a image on the canvas and then draw on it so you can make good looking pictures / Will make the program stand out

import pygame
import os
pygame.init()
pygame.font.init()

# Setup Display
win = pygame.display.set_mode((750, 500), pygame.RESIZABLE)
pygame.display.set_caption("Drawing Program")

# Saving
#file = open("log.txt", "r")

# Variables
run = True
pixels = []
can_draw = False
brush_size = 3
cur_color = (10, 10, 10)
cur_color_R = 10
cur_color_G = 10
cur_color_B = 10
saving_image = False
erasing = False
tracing = False

# Fonts
#font = pygame.font.match_font("comic sans")
Med_Font = pygame.font.Font("Poppins-SemiBold.ttf", 20)
# Images		os.path.join("img", "Icon.png")

icon = pygame.image.load(os.path.join("Icon.png"))
#icon.set_colorkey((230, 230, 230))
pygame.display.set_icon(icon)

try:
	refimage = pygame.image.load(os.path.join("ref.png")).convert()
except:
	refimage = pygame.image.load(os.path.join("ref.jpg")).convert()
else:
	pass
#else:
#	refimage = pygame.image.load(os.path.join("reference", "ref.bmp")).convert()


refimage.set_alpha(100)

# Time
FPS = 60
clock = pygame.time.Clock()

# Pixel Class
class Pixel:
	def __init__(self, mx, my, color = (10, 10, 10), size = 3):
		self.mx = mx
		self.my = my
		self.color = color
		self.size = size

	def get_mx(self):
		return self.mx 

	def get_my(self):
		return self.my 

	def get_col(self):
		return self.color

	def get_size(self):
		return self.size

# Redraws Game Window
def RedrawGameWindow(UI = True):
	if UI:
		# Get mouse position
		mx, my = pygame.mouse.get_pos()

		win.fill((245, 245, 245))

		for p in pixels:
			pygame.draw.rect(win, p.get_col(), (p.get_mx(), p.get_my(), p.get_size(), p.get_size()))

		win.blit(Size_Label, ((win.get_width() + 10) - win.get_width(), win.get_height() - 35))

		win.blit(Color_Label, (win.get_width() - 180, win.get_height() - 35))
		pygame.draw.rect(win, cur_color, (win.get_width() - 210, win.get_height() - 29, 16, 16))

		if not erasing:
			pygame.draw.rect(win, (10, 10, 10), (mx - (brush_size // 2), my - (brush_size // 2), brush_size, brush_size), 1)
			pygame.draw.rect(win, (255, 255, 255), (mx - (brush_size // 2) - 1, my - (brush_size // 2) - 1, brush_size + 2, brush_size + 2), 1)

		if erasing:
			pygame.draw.rect(win, (180, 20, 20), (mx - (brush_size // 2), my - (brush_size // 2), brush_size, brush_size), 1)
			pygame.draw.rect(win, (255, 255, 255), (mx - (brush_size // 2) - 1, my - (brush_size // 2) - 1, brush_size + 2, brush_size + 2), 1)
		#pygame.draw.rect(win, (10, 10, 10), (100, 473 - (brush_size), brush_size, brush_size), 1)		

		if tracing:
			win.blit(refimage, ((win.get_width() // 2) - (refimage.get_width() // 2), (win.get_height() // 2) - (refimage.get_height() // 2)))	


		pygame.display.update()

	# Saving Image
	elif not UI:
		# No UI Version
		win.fill((245, 245, 245))

		for p in pixels:
			pygame.draw.rect(win, p.get_col(), (p.get_mx(), p.get_my(), p.get_size(), p.get_size()))

		pygame.display.update()
		# Saving Image
		pygame.image.save(win, os.path.join("drawings", "Drawing.png"))


# Draw on-screen
def Draw():
	pixel = Pixel(mx - brush_size // 2, my - brush_size // 2, cur_color, brush_size)
	pixels.append(pixel)

# Erasing, need to fix collision
def Erase():
	pixel = Pixel(mx - brush_size // 2, my - brush_size // 2, (245, 245, 245), brush_size)
	pixels.append(pixel)
	

	# Actually removes the pixel from the list, however this is worse than painting over it
	#mx, my = pygame.mouse.get_pos()
	#for pixel in pixels:
			#if mx > (pixel.get_mx() - pixel.get_size()) and mx < (pixel.get_mx() + pixel.get_size()) and my < (pixel.get_my() + pixel.get_size()) and my > (pixel.get_my() - pixel.get_size()):
			#if my < (pixel.get_my() + pixel.get_size()) and my > (pixel.get_my() - pixel.get_size()):
				#print("erase")
			#	pixels.remove(pixel)

			#if pixel.get_mx() >= mx or pixel.get_mx() <= (mx + brush_size) and pixel.get_my() >= my and pixel.get_my() <= (my + brush_size):
			#if pixel.get_mx() >= mx - 2 or pixel.get_mx() <= mx + 2 and pixel.get_my() >= my - 2 and pixel.get_my() <= my + 2:
				#pixels.remove(pixel)
				#print("erase")
			#else:
				#pass

# Don't make pixel on top of others
def Collision():
	mx, my = pygame.mouse.get_pos()
	for pixel in pixels:
			if pixel.get_mx() >= mx or pixel.get_mx() <= (mx + brush_size) and pixel.get_my() >= my and pixel.get_my() <= (my + brush_size):
				#print("col")
				return True
			else:
				return False

#def Center()
#def read_integers(filename):
  #  with open(filename) as f:
    #    return [int(x) for x in f]

# Game Loop
while run:

	#if saved_image_num == "1":
	#	print("Shazam!")

	Use_UI = True
	# Don't make pixel on top of others
	Collision()


	# Set labels 
	Size_Label = Med_Font.render("Size: " + str(brush_size), 1, (10, 10, 10))
	Color_Label = Med_Font.render("Color: " + str(cur_color), 1, (10, 10, 10))

	# Set Color
	cur_color = (cur_color_R, cur_color_G, cur_color_B)


	# Event Handling
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False
	#	if event.type == pygame.MOUSEMOTION:
		#	if can_draw:
		#		mx, my = pygame.mouse.get_pos()
			#	pixelX = mx
			#	pixelY = my
			#	Draw()
		
		# Resizing Window
		if event.type == pygame.VIDEORESIZE:
			win = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)

		if event.type == pygame.MOUSEBUTTONDOWN:
			can_draw = True
			mx, my = pygame.mouse.get_pos()
			pixelX = mx
			pixelY = my
			if not erasing:
				Draw()
			elif erasing:
				Erase()
		if event.type == pygame.MOUSEBUTTONUP:
			can_draw = False
		if event.type == pygame.KEYDOWN:
			key = pygame.key.get_pressed()
			if key[pygame.K_a]:
				if brush_size > 1:
					brush_size -= 1
					print(brush_size)
			if key[pygame.K_d]:
				brush_size += 1
				print(brush_size)

			# Color Controls 
			if key[pygame.K_r]:
				cur_color_R = 240
				cur_color_G = 10
				cur_color_B = 10
				cur_color = (cur_color_R, cur_color_G, cur_color_B)
				print(cur_color)

			if key[pygame.K_g]:
				cur_color_R = 10
				cur_color_G = 240
				cur_color_B = 10
				cur_color = (cur_color_R, cur_color_G, cur_color_B)
				print(cur_color)

			if key[pygame.K_b]:
				cur_color_R = 10
				cur_color_G = 10
				cur_color_B = 240
				cur_color = (cur_color_R, cur_color_G, cur_color_B)
				print(cur_color)

			if key[pygame.K_s]:
				cur_color_R = 10
				cur_color_G = 10
				cur_color_B = 10
				cur_color = (cur_color_R, cur_color_G, cur_color_B)
				print(cur_color)


			# Numpad Color Controls
			if key[pygame.K_KP7]:
				if cur_color_R < 250:
					cur_color_R += 10
				print(cur_color)
			elif key[pygame.K_KP4]:
				if cur_color_R > 0:
					cur_color_R -= 10
				print(cur_color)

			if key[pygame.K_KP8]:
				if cur_color_G < 250:
					cur_color_G += 10
				print(cur_color)
			elif key[pygame.K_KP5]:
				if cur_color_G > 0:
					cur_color_G -= 10
				print(cur_color)

			if key[pygame.K_KP9]:
				if cur_color_B < 250:
					cur_color_B += 10
				print(cur_color)
			elif key[pygame.K_KP6]:
				if cur_color_B > 0:
					cur_color_B -= 10
				print(cur_color)

			# Clear
			if key[pygame.K_q]:
				for x in range(20):
					for p in pixels:
						pixels.remove(p)
				print("Cleared!")

			# Save Image
			if key[pygame.K_F12]:
				Use_UI = False
				print("Screen Shot Taken!")
			# Set win size to default
			if key[pygame.K_TAB]:
				win = pygame.display.set_mode((750, 500), pygame.RESIZABLE)
				print("Reset To Default Window Size!")
			# Erase
			if key[pygame.K_e]:
				if not erasing:
					erasing = True
					print(erasing)
					break
					
				if erasing:
					erasing = False
					print(erasing)
					break
			
			# Tracing Mode
			if key[pygame.K_t]:
				if not tracing:
					tracing = True
					print(tracing)
					break
					
				if tracing:
					tracing = False
					print(tracing)
					break	
			#if key[pygame.K_F11]:
			#	test = read_integers("log.txt")
			#	print(int(test))
	# Detects Collision
	

	# Draws with Pen
	if can_draw:
		#if not Collision():
			mx, my = pygame.mouse.get_pos()
			pixelX = mx
			pixelY = my

			if not erasing:
				Draw()
			if erasing:
				Erase()
	#	else:
		#	pass


	# Draws 
	RedrawGameWindow(Use_UI)

	# Frame Elapses
	clock.tick(FPS)

# When loop stops running, quit pygame
pygame.quit()